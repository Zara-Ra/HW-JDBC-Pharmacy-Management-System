package data.enums;

public enum RoleType {
    ADMIN,
    PATIENT
}
